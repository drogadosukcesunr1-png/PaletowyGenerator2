# paletowy_gui.py
# Paletowy Generator by Aurion
# Requires: Python 3.9+, pip install pandas requests
# GUI: Tkinter (included with Python on Windows)

import tkinter as tk
from tkinter import filedialog, messagebox
import pandas as pd
import requests
import os
import html
from datetime import datetime
from urllib.parse import quote_plus

# Settings
EUR_TO_PLN = 4.25
PLACEHOLDER = "https://via.placeholder.com/100?text=No+Image"

def choose_file():
    path = filedialog.askopenfilename(
        title="Wybierz plik CSV",
        filetypes=[("CSV files","*.csv"), ("All files","*.*")]
    )
    if path:
        entry_path.delete(0, tk.END)
        entry_path.insert(0, path)

def generate_html():
    csv_path = entry_path.get().strip()
    if not csv_path or not os.path.isfile(csv_path):
        messagebox.showerror("Błąd", "Wskaż poprawny plik CSV.")
        return

    try:
        df = pd.read_csv(csv_path, dtype=str)
    except Exception as e:
        messagebox.showerror("Błąd", f"Nie można wczytać pliku CSV:\\n{e}")
        return

    cols = [c.strip() for c in df.columns]
    df.columns = cols

    needed = ["Pallet ID","ASIN","Item Desc","UNIT RETAIL","QTY"]
    for col in needed:
        if col not in df.columns:
            df[col] = ""

    df["CenaEUR"] = pd.to_numeric(df["UNIT RETAIL"], errors="coerce")
    df["QTY_NUM"] = pd.to_numeric(df["QTY"], errors="coerce").fillna(1).astype(int)

    def asin_to_img(asin):
        if not isinstance(asin, str) or not asin.strip():
            return PLACEHOLDER
        a = asin.strip()
        return f"https://images-na.ssl-images-amazon.com/images/P/{quote_plus(a)}.jpg"

    df["ImgURL"] = df["ASIN"].apply(asin_to_img)

    df_sorted = df.sort_values(by="CenaEUR", ascending=False, na_position="last").reset_index(drop=True)

    base = os.path.splitext(os.path.basename(csv_path))[0]
    date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    out_name = f"spis_{date_str}_{base}.html"
    out_path = os.path.join(os.path.dirname(csv_path), out_name)

    html_lines = [
        "<!doctype html>",
        "<html><head><meta charset='utf-8'><title>Spis produktów</title>",
        "<style>",
        "body{font-family:Arial,Helvetica,sans-serif;margin:20px;background:#0f1720;color:#e6eef8}",
        ".prod{display:flex;gap:12px;padding:10px;border-bottom:1px solid #122027}",
        ".prod img{width:100px;height:auto;object-fit:contain;background:#fff;padding:6px;border-radius:4px}",
        ".meta{color:#9fb1bf;font-size:0.9em}",
        ".price{font-weight:700;margin-top:6px}",
        "a{color:#9fe7ff}",
        "</style>",
        "</head><body>",
        f"<h1>Paletowy Generator — spis: {html.escape(base)}</h1>",
        f"<p>Wygenerowano: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>",
        "<div>"
    ]

    total_eur = 0.0
    total_pln = 0.0

    for _, row in df_sorted.iterrows():
        asin = str(row.get("ASIN","") or "")
        desc = str(row.get("Item Desc","") or "")
        pallet = str(row.get("Pallet ID","") or "")
        qty = int(row.get("QTY_NUM",1))
        cena_eur = row.get("CenaEUR")
        cena_eur_val = float(cena_eur) if pd.notna(cena_eur) else None
        cena_pln_val = (cena_eur_val * EUR_TO_PLN) if cena_eur_val is not None else None

        if cena_eur_val is not None:
            total_eur += cena_eur_val * qty
            total_pln += cena_pln_val * qty

        img = row.get("ImgURL") or PLACEHOLDER
        cena_eur_str = f"{cena_eur_val:.2f} EUR" if cena_eur_val is not None else "brak"
        cena_pln_str = f"{cena_pln_val:.2f} PLN" if cena_pln_val is not None else "brak"

        html_lines.append(
            "<div class='prod'>"
            f"<img src='{html.escape(img)}' alt='{html.escape(asin)}' onerror=\"this.onerror=null;this.src='{PLACEHOLDER}';\">"
            "<div>"
            f"<div><strong>{html.escape(desc)}</strong></div>"
            f"<div class='meta'>ASIN: {html.escape(asin)} · Paleta: {html.escape(pallet)} · Ilość (QTY): {qty}</div>"
            f"<div class='price'>{cena_eur_str} / {cena_pln_str}</div>"
            "</div></div>"
        )

    html_lines.append("<hr>")
    html_lines.append("<h2>Podsumowanie</h2>")
    html_lines.append(f"<p>Liczba pozycji: {len(df_sorted)}</p>")
    html_lines.append(f"<p>Wartość całkowita (EUR): <strong>{total_eur:.2f} EUR</strong></p>")
    html_lines.append(f"<p>Wartość całkowita (PLN): <strong>{total_pln:.2f} PLN</strong></p>")

    html_lines.append("</div></body></html>")

    try:
        with open(out_path, "w", encoding="utf-8") as f:
            f.write("\n".join(html_lines))
    except Exception as e:
        messagebox.showerror("Błąd zapisu", f"Nie można zapisać pliku HTML:\\n{e}")
        return

    messagebox.showinfo("Gotowe", f"Plik wygenerowany:\\n{out_path}")
    try:
        os.startfile(os.path.dirname(out_path))
    except Exception:
        pass

# GUI
root = tk.Tk()
root.title("Paletowy Generator by Aurion")
root.geometry("700x180")
frm = tk.Frame(root, padx=10, pady=10)
frm.pack(fill="both", expand=True)

lbl = tk.Label(frm, text="Plik CSV:", fg="#e6eef8", bg="#0f1720")
lbl.grid(row=0, column=0, sticky="w")
entry_path = tk.Entry(frm, width=60)
entry_path.grid(row=0, column=1, padx=6)
btn_browse = tk.Button(frm, text="Wybierz plik CSV", command=choose_file)
btn_browse.grid(row=0, column=2, padx=6)

btn_gen = tk.Button(frm, text="Generuj spis HTML", bg="#2E8B57", fg="white", command=generate_html)
btn_gen.grid(row=1, column=1, pady=20)

# Apply dark bg to window/frame
try:
    root.configure(bg="#0f1720")
    frm.configure(bg="#0f1720")
    entry_path.configure(bg="#1a2430", fg="#e6eef8", insertbackground="#e6eef8")
    btn_browse.configure(bg="#2b3942", fg="#e6eef8")
except Exception:
    pass

root.mainloop()
